package com.dicoding.submission

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView

class DetailActivity : AppCompatActivity() {

    // Deklarasikan variabel plantName sebagai properti kelas
    private var plantName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        setTitle("MyPlants Detail")
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Menerima data dari Intent dan mengisi variabel plantName
        plantName = intent.getStringExtra("plant_name")
        val plantLatin = intent.getStringExtra("plant_latin")
        val plantDescription = intent.getStringExtra("plant_description")
        val plantImage = intent.getIntExtra("plant_image", 0)
        val plantHarga = intent.getStringExtra("plant_harga")

        // Mengakses tampilan dalam layout
        val nameTextView = findViewById<TextView>(R.id.tv_item_name)
        val latinTextView = findViewById<TextView>(R.id.tv_item_latin)
        val descriptionTextView = findViewById<TextView>(R.id.tv_item_description)
        val hargaTextView = findViewById<TextView>(R.id.tv_item_harga)
        val imageView = findViewById<ImageView>(R.id.imageView)

        // Mengatur teks dan gambar sesuai dengan data yang diterima
        nameTextView.text = plantName
        latinTextView.text =plantLatin
        descriptionTextView.text = plantDescription
        hargaTextView.text = plantHarga
        imageView.setImageResource(plantImage)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                // Aksi ketika tombol kembali ditekan
                onBackPressed() // Ini akan kembali ke intent sebelumnya
                return true
            }
            R.id.action_share -> {
                // Tindakan yang akan diambil saat tombol "Share" ditekan
                val shareIntent = Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_TEXT, "The $plantName MyPlants Details...")
                startActivity(Intent.createChooser(shareIntent, "Bagikan lewat"))
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return true
    }
}
