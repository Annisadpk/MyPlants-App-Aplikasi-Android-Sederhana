package com.dicoding.submission

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ListPlantAdapter(private val listPlant: ArrayList<Plant>) : RecyclerView.Adapter<ListPlantAdapter.ListViewHolder>() {
    private var onItemClickCallback: OnItemClickCallback? = null

    interface OnItemClickCallback {
        fun onItemClicked(plant: Plant)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_plant, parent, false)
        return ListViewHolder(view)
    }

    override fun getItemCount(): Int = listPlant.size

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (name, latin, _,  photo, harga) = listPlant[position]
        holder.imgPhoto.setImageResource(photo)
        holder.tvName.text = name
        holder.tvLatin.text = latin
        holder.tvHarga.text = harga

        // Menambahkan listener untuk meng-handle item yang diklik
        holder.itemView.setOnClickListener {
            onItemClickCallback?.onItemClicked(listPlant[holder.adapterPosition])
        }
    }

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvLatin: TextView = itemView.findViewById(R.id.tv_item_latin)
        val tvHarga: TextView = itemView.findViewById(R.id.tv_item_harga)
    }
}
