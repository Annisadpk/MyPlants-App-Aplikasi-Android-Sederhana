package com.dicoding.submission

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvPlants: RecyclerView
    private val list = ArrayList<Plant>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rvPlants = findViewById(R.id.rv_plants)
        rvPlants.setHasFixedSize(true)

        list.addAll(getListPlants())
        showRecyclerList()
    }

    private fun getListPlants(): ArrayList<Plant> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataLatin = resources.getStringArray(R.array.data_latin)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val dataHarga = resources.getStringArray(R.array.data_harga)
        val listPlant = ArrayList<Plant>()
        for (i in dataName.indices) {
            val plant = Plant(dataName[i], dataLatin[i], dataDescription[i], dataPhoto.getResourceId(i, -1), dataHarga[i])
            listPlant.add(plant)
        }
        dataPhoto.recycle() // Mereset dataPhoto setelah digunakan
        return listPlant
    }

    private fun showRecyclerList() {
        rvPlants.layoutManager = LinearLayoutManager(this)
        val listPlantAdapter = ListPlantAdapter(list)
        rvPlants.adapter = listPlantAdapter

        listPlantAdapter.setOnItemClickCallback(object : ListPlantAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Plant) {
                // Handle item click di sini, contohnya, berpindah ke halaman detail
                val detailIntent = Intent(this@MainActivity, DetailActivity::class.java)

                // Mengirim data terkait item yang diklik ke DetailActivity
                detailIntent.putExtra("plant_name", data.name)
                detailIntent.putExtra("plant_latin", data.latin)
                detailIntent.putExtra("plant_description", data.description)
                detailIntent.putExtra("plant_image", data.photo)
                detailIntent.putExtra("plant_harga", data.harga)

                startActivity(detailIntent)
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_aboutme -> {
                val aboutIntent = Intent(this, AboutActivity::class.java)
                startActivity(aboutIntent)
                return true
            }

            else -> return super.onOptionsItemSelected(item)
        }
    }
}
